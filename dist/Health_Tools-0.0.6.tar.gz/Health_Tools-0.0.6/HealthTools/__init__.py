from .Ver_arterial_pression import Ver_arterial_pression
from .verifica_imc import verifica_imc
from .calcular_tfg import calcular_tfg
from .contar_hemacias import contar_hemacias
from .contar_leucocitos import contar_leucocitos
from .contar_plaquetas import contar_plaquetas
from .calcular_fcm import calcular_fcm
from .calcular_frequencia_respiratoria import calcular_frequencia_respiratoria
from .calcular_debito_cardiaco import calcular_debito_cardiaco
from .calcular_tp import calcular_tp
from .calcular_ttpa import calcular_ttpa
from .calcular_indice_apgar import calcular_indice_apgar
from .classificar_pvc import classificar_pvc
from. classificar_glicemia import classificar_glicemia
from. classifica_saturacao_spo2 import classificar_spo2
from. calcular_debito_urinario import calcular_debito_urinario
from.classificar_espirometria import classificar_espirometria
from.classifica_capacidade_anaerobica import teste_capacidade_anaerobica
from.teste_funcao_renal import teste_funcao_renal
from.teste_funcao_hepatica import teste_funcao_hepatica
from.classifica_tireoidiana import teste_funcao_tireoidiana
from.help import help
